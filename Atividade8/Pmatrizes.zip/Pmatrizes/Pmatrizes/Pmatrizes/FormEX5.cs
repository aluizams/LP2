﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pmatrizes
{
    public partial class FormEX5 : Form
    {
        int[] tamanhoSemespaco = new int[6];
        int cont = 0;
        string[] nomes = new string[6];
        string resultado = "";

        public FormEX5()
        {
            InitializeComponent();
        }

        private void btniniciar_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 6; i++)
            {
                nomes[i] = Interaction.InputBox($"Insira o {i + 1}º nome");
                foreach (char c in nomes[i])
                {
                    if (!char.IsLetter(c) && !char.IsWhiteSpace(c))
                    {
                        MessageBox.Show("nome inválido");
                        i--;
                    }
                }


                }
                for (var x = 0; x < 6; x++)
                {
                    tamanhoSemespaco[x] = nomes[x].Length;
                    cont = 0;
                    for (int i = 0; i < nomes[x].Length; i++)
                    {
                        if (char.IsWhiteSpace(nomes[x][i]))
                        {
                            cont++;
                            tamanhoSemespaco[x] -= cont;
                        }
                    }

                }
                btnexecutar.Focus();
            }

        private void btnexecutar_Click(object sender, EventArgs e)
        {

            resultado = "";
            for (int i = 0; i < 6; i++)
            {
                resultado = $"\no nome: {nomes[i]} tem {tamanhoSemespaco[i]}  letras";
                Lbox.Items.Add(resultado);

            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            Lbox.Items.Clear();
            btniniciar.Focus();
        }
    }
    }


        

    

