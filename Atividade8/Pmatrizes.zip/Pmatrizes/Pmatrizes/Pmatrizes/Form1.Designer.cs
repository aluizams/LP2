﻿namespace Pmatrizes
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnexe1 = new System.Windows.Forms.Button();
            this.btnexe2 = new System.Windows.Forms.Button();
            this.btnexe3 = new System.Windows.Forms.Button();
            this.btnexe4 = new System.Windows.Forms.Button();
            this.btnexe5 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnexe1
            // 
            this.btnexe1.Location = new System.Drawing.Point(70, 57);
            this.btnexe1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnexe1.Name = "btnexe1";
            this.btnexe1.Size = new System.Drawing.Size(80, 48);
            this.btnexe1.TabIndex = 0;
            this.btnexe1.Text = "Exercício 1";
            this.btnexe1.UseVisualStyleBackColor = true;
            this.btnexe1.Click += new System.EventHandler(this.Btnexe1_Click);
            // 
            // btnexe2
            // 
            this.btnexe2.Location = new System.Drawing.Point(191, 57);
            this.btnexe2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnexe2.Name = "btnexe2";
            this.btnexe2.Size = new System.Drawing.Size(80, 48);
            this.btnexe2.TabIndex = 1;
            this.btnexe2.Text = "Exercício 2";
            this.btnexe2.UseVisualStyleBackColor = true;
            this.btnexe2.Click += new System.EventHandler(this.Btnexe2_Click);
            // 
            // btnexe3
            // 
            this.btnexe3.Location = new System.Drawing.Point(312, 57);
            this.btnexe3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnexe3.Name = "btnexe3";
            this.btnexe3.Size = new System.Drawing.Size(80, 48);
            this.btnexe3.TabIndex = 2;
            this.btnexe3.Text = "Exercício 3";
            this.btnexe3.UseVisualStyleBackColor = true;
            this.btnexe3.Click += new System.EventHandler(this.btnexe3_Click);
            // 
            // btnexe4
            // 
            this.btnexe4.Location = new System.Drawing.Point(70, 169);
            this.btnexe4.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnexe4.Name = "btnexe4";
            this.btnexe4.Size = new System.Drawing.Size(80, 48);
            this.btnexe4.TabIndex = 3;
            this.btnexe4.Text = "Exercício 4";
            this.btnexe4.UseVisualStyleBackColor = true;
            this.btnexe4.Click += new System.EventHandler(this.btnexe4_Click);
            // 
            // btnexe5
            // 
            this.btnexe5.Location = new System.Drawing.Point(191, 169);
            this.btnexe5.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnexe5.Name = "btnexe5";
            this.btnexe5.Size = new System.Drawing.Size(80, 48);
            this.btnexe5.TabIndex = 4;
            this.btnexe5.Text = "Exercício 5";
            this.btnexe5.UseVisualStyleBackColor = true;
            this.btnexe5.Click += new System.EventHandler(this.btnexe5_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(533, 292);
            this.Controls.Add(this.btnexe5);
            this.Controls.Add(this.btnexe4);
            this.Controls.Add(this.btnexe3);
            this.Controls.Add(this.btnexe2);
            this.Controls.Add(this.btnexe1);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnexe1;
        private System.Windows.Forms.Button btnexe2;
        private System.Windows.Forms.Button btnexe3;
        private System.Windows.Forms.Button btnexe4;
        private System.Windows.Forms.Button btnexe5;
    }
}

