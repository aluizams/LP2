﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pmatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Btnexe1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];

            string auxiliar = "";
            string saida = "";

            for (var i = 0; i < 20; i++)
            {
                auxiliar = Interaction.InputBox($"Entre com um número {i+1}", "Entrada de dados");

                if (auxiliar == "")
                    return;

                if (!int.TryParse(auxiliar, out vetor[i]))

                {
                    MessageBox.Show("número inválido");
                    i--;
                }
                else //conversao ok
                {
                    saida = vetor[i] + "\n" + saida;
                }
            }
            MessageBox.Show(saida);

            // usando reverse
            /*Array.Reverse(vetor);
            auxiliar = "";
            foreach (int x in vetor)
            auxiliar += x + "\n";
            MessageBox.Show(auxiliar);

            // for ao contrario
             auxiliar = "";
            for (var j = 19; j >= 0; j--)
                auxiliar += vetor[j] + "\n";
            MessageBox.Show(auxiliar);*/ 
        }

        private void Btnexe2_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20, 3];
           
            double[] medias = new double[20];
            string auxiliar = "";
            

            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j <3; j++)
                {
                    auxiliar = Interaction.InputBox($"Entre com a nota {j + 1} do aluno {i+1}", "Entrada de dados");

                    if (auxiliar == "")
                        return;

                    if (!double.TryParse(auxiliar, out notas[i,j]))

                    {
                        MessageBox.Show("número inválido");
                        i--;
                    }
                    else
                    {
                        if (notas[i, j] >= 0 && notas[i, j] < 10)
                        {

                            medias[i] = medias[i] + notas[i, j];
                            
                        }
                        else
                        {
                            MessageBox.Show("Número inválido");
                            i--;
                        }
                       
                    }
                }
                medias[i] = medias[i] / 3;

            }
            for (int i =0; i<20; i++)
            {
                auxiliar = "";
                auxiliar = auxiliar + "aluno: " + i + " media: " + medias[i].ToString("N2");
                MessageBox.Show(auxiliar);

            }
        }

        private void btnexe3_Click(object sender, EventArgs e)
        {
            string[] Alunos = {"Viviane", "André", "Hélio", "Denise", "Junior",
"Leonardo", "Jose", "Nelma", "Tobby"};
            Int32 I, Total = 0;
            Int32 N = Alunos.Length;
            for (I = 0; I < N - 1; I++)
            {
                Total += Alunos[I].Length;
            }
            MessageBox.Show(Total.ToString());
        }

        private void btnexe4_Click(object sender, EventArgs e)
        {
            ArrayList alunos = new ArrayList() { "Ana", "André", "Débora", "Fátima", "João", "Janete", "Otávio", "Marcelo", "Pedro", "Thais" };
            alunos.Remove("Otávio");
            string auxiliar = "";
            foreach (var x in alunos)
            {
                auxiliar += x.ToString() + "; \n";
            }
            MessageBox.Show(auxiliar);


        }

        private void btnexe5_Click(object sender, EventArgs e)
        {
            FormEX5 formEX5 = new FormEX5();
            formEX5.Show();

        }
    }
}
