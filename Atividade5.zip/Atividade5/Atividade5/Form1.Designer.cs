﻿namespace Atividade5
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblnomefunc = new System.Windows.Forms.Label();
            this.lblsalbruto = new System.Windows.Forms.Label();
            this.lblnumfil = new System.Windows.Forms.Label();
            this.lblalqinss = new System.Windows.Forms.Label();
            this.lblaliirpf = new System.Windows.Forms.Label();
            this.lblsalfam = new System.Windows.Forms.Label();
            this.lblsalliq = new System.Windows.Forms.Label();
            this.lbldescinss = new System.Windows.Forms.Label();
            this.lbldescirpf = new System.Windows.Forms.Label();
            this.btnverif = new System.Windows.Forms.Button();
            this.msktxtsalb = new System.Windows.Forms.MaskedTextBox();
            this.numfilhos = new System.Windows.Forms.NumericUpDown();
            this.txtnome = new System.Windows.Forms.TextBox();
            this.msktxtinss = new System.Windows.Forms.MaskedTextBox();
            this.msktxtdescinss = new System.Windows.Forms.MaskedTextBox();
            this.msktxtdescirpf = new System.Windows.Forms.MaskedTextBox();
            this.msktxtirpf = new System.Windows.Forms.MaskedTextBox();
            this.msktxtsalfam = new System.Windows.Forms.MaskedTextBox();
            this.msktxtsalliq = new System.Windows.Forms.MaskedTextBox();
            this.errorSalBruto = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.numfilhos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorSalBruto)).BeginInit();
            this.SuspendLayout();
            // 
            // lblnomefunc
            // 
            this.lblnomefunc.AutoSize = true;
            this.lblnomefunc.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblnomefunc.Location = new System.Drawing.Point(39, 57);
            this.lblnomefunc.Name = "lblnomefunc";
            this.lblnomefunc.Size = new System.Drawing.Size(90, 13);
            this.lblnomefunc.TabIndex = 0;
            this.lblnomefunc.Text = "Nome funcionário";
            // 
            // lblsalbruto
            // 
            this.lblsalbruto.AutoSize = true;
            this.lblsalbruto.Location = new System.Drawing.Point(39, 92);
            this.lblsalbruto.Name = "lblsalbruto";
            this.lblsalbruto.Size = new System.Drawing.Size(67, 13);
            this.lblsalbruto.TabIndex = 1;
            this.lblsalbruto.Text = "Salário Bruto";
            // 
            // lblnumfil
            // 
            this.lblnumfil.AutoSize = true;
            this.lblnumfil.Location = new System.Drawing.Point(39, 137);
            this.lblnumfil.Name = "lblnumfil";
            this.lblnumfil.Size = new System.Drawing.Size(86, 13);
            this.lblnumfil.TabIndex = 2;
            this.lblnumfil.Text = "Número de filhos";
            // 
            // lblalqinss
            // 
            this.lblalqinss.AutoSize = true;
            this.lblalqinss.Location = new System.Drawing.Point(39, 208);
            this.lblalqinss.Name = "lblalqinss";
            this.lblalqinss.Size = new System.Drawing.Size(75, 13);
            this.lblalqinss.TabIndex = 3;
            this.lblalqinss.Text = "Alíquota INSS";
            // 
            // lblaliirpf
            // 
            this.lblaliirpf.AutoSize = true;
            this.lblaliirpf.Location = new System.Drawing.Point(39, 250);
            this.lblaliirpf.Name = "lblaliirpf";
            this.lblaliirpf.Size = new System.Drawing.Size(74, 13);
            this.lblaliirpf.TabIndex = 4;
            this.lblaliirpf.Text = "Alíquota IRPF";
            // 
            // lblsalfam
            // 
            this.lblsalfam.AutoSize = true;
            this.lblsalfam.Location = new System.Drawing.Point(39, 289);
            this.lblsalfam.Name = "lblsalfam";
            this.lblsalfam.Size = new System.Drawing.Size(76, 13);
            this.lblsalfam.TabIndex = 5;
            this.lblsalfam.Text = "Salário Família";
            // 
            // lblsalliq
            // 
            this.lblsalliq.AutoSize = true;
            this.lblsalliq.Location = new System.Drawing.Point(39, 330);
            this.lblsalliq.Name = "lblsalliq";
            this.lblsalliq.Size = new System.Drawing.Size(78, 13);
            this.lblsalliq.TabIndex = 6;
            this.lblsalliq.Text = "Salário Líquido";
            // 
            // lbldescinss
            // 
            this.lbldescinss.AutoSize = true;
            this.lbldescinss.Location = new System.Drawing.Point(280, 208);
            this.lbldescinss.Name = "lbldescinss";
            this.lbldescinss.Size = new System.Drawing.Size(81, 13);
            this.lbldescinss.TabIndex = 7;
            this.lbldescinss.Text = "Desconto INSS";
            // 
            // lbldescirpf
            // 
            this.lbldescirpf.AutoSize = true;
            this.lbldescirpf.Location = new System.Drawing.Point(280, 250);
            this.lbldescirpf.Name = "lbldescirpf";
            this.lbldescirpf.Size = new System.Drawing.Size(80, 13);
            this.lbldescirpf.TabIndex = 8;
            this.lbldescirpf.Text = "Desconto IRPF";
            // 
            // btnverif
            // 
            this.btnverif.Location = new System.Drawing.Point(367, 127);
            this.btnverif.Name = "btnverif";
            this.btnverif.Size = new System.Drawing.Size(122, 23);
            this.btnverif.TabIndex = 9;
            this.btnverif.Text = "Verificar Desconto";
            this.btnverif.UseVisualStyleBackColor = true;
            this.btnverif.Click += new System.EventHandler(this.btnverif_Click);
            // 
            // msktxtsalb
            // 
            this.msktxtsalb.Location = new System.Drawing.Point(131, 89);
            this.msktxtsalb.Mask = "00000.00";
            this.msktxtsalb.Name = "msktxtsalb";
            this.msktxtsalb.Size = new System.Drawing.Size(100, 20);
            this.msktxtsalb.TabIndex = 10;
            this.msktxtsalb.Validated += new System.EventHandler(this.msktxtsalb_Validated);
            // 
            // numfilhos
            // 
            this.numfilhos.Location = new System.Drawing.Point(131, 135);
            this.numfilhos.Name = "numfilhos";
            this.numfilhos.Size = new System.Drawing.Size(120, 20);
            this.numfilhos.TabIndex = 11;
            // 
            // txtnome
            // 
            this.txtnome.Location = new System.Drawing.Point(135, 54);
            this.txtnome.Name = "txtnome";
            this.txtnome.Size = new System.Drawing.Size(100, 20);
            this.txtnome.TabIndex = 12;
            this.txtnome.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtnome_KeyPress);
            // 
            // msktxtinss
            // 
            this.msktxtinss.Enabled = false;
            this.msktxtinss.Location = new System.Drawing.Point(120, 205);
            this.msktxtinss.Name = "msktxtinss";
            this.msktxtinss.Size = new System.Drawing.Size(100, 20);
            this.msktxtinss.TabIndex = 13;
            // 
            // msktxtdescinss
            // 
            this.msktxtdescinss.Enabled = false;
            this.msktxtdescinss.Location = new System.Drawing.Point(367, 205);
            this.msktxtdescinss.Name = "msktxtdescinss";
            this.msktxtdescinss.Size = new System.Drawing.Size(100, 20);
            this.msktxtdescinss.TabIndex = 14;
            // 
            // msktxtdescirpf
            // 
            this.msktxtdescirpf.Enabled = false;
            this.msktxtdescirpf.Location = new System.Drawing.Point(366, 247);
            this.msktxtdescirpf.Name = "msktxtdescirpf";
            this.msktxtdescirpf.Size = new System.Drawing.Size(100, 20);
            this.msktxtdescirpf.TabIndex = 15;
            // 
            // msktxtirpf
            // 
            this.msktxtirpf.Enabled = false;
            this.msktxtirpf.Location = new System.Drawing.Point(120, 247);
            this.msktxtirpf.Name = "msktxtirpf";
            this.msktxtirpf.Size = new System.Drawing.Size(100, 20);
            this.msktxtirpf.TabIndex = 16;
            // 
            // msktxtsalfam
            // 
            this.msktxtsalfam.Enabled = false;
            this.msktxtsalfam.Location = new System.Drawing.Point(120, 286);
            this.msktxtsalfam.Name = "msktxtsalfam";
            this.msktxtsalfam.Size = new System.Drawing.Size(100, 20);
            this.msktxtsalfam.TabIndex = 17;
            // 
            // msktxtsalliq
            // 
            this.msktxtsalliq.Enabled = false;
            this.msktxtsalliq.Location = new System.Drawing.Point(123, 327);
            this.msktxtsalliq.Name = "msktxtsalliq";
            this.msktxtsalliq.Size = new System.Drawing.Size(100, 20);
            this.msktxtsalliq.TabIndex = 18;
            // 
            // errorSalBruto
            // 
            this.errorSalBruto.ContainerControl = this;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.msktxtsalliq);
            this.Controls.Add(this.msktxtsalfam);
            this.Controls.Add(this.msktxtirpf);
            this.Controls.Add(this.msktxtdescirpf);
            this.Controls.Add(this.msktxtdescinss);
            this.Controls.Add(this.msktxtinss);
            this.Controls.Add(this.txtnome);
            this.Controls.Add(this.numfilhos);
            this.Controls.Add(this.msktxtsalb);
            this.Controls.Add(this.btnverif);
            this.Controls.Add(this.lbldescirpf);
            this.Controls.Add(this.lbldescinss);
            this.Controls.Add(this.lblsalliq);
            this.Controls.Add(this.lblsalfam);
            this.Controls.Add(this.lblaliirpf);
            this.Controls.Add(this.lblalqinss);
            this.Controls.Add(this.lblnumfil);
            this.Controls.Add(this.lblsalbruto);
            this.Controls.Add(this.lblnomefunc);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.numfilhos)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorSalBruto)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblnomefunc;
        private System.Windows.Forms.Label lblsalbruto;
        private System.Windows.Forms.Label lblnumfil;
        private System.Windows.Forms.Label lblalqinss;
        private System.Windows.Forms.Label lblaliirpf;
        private System.Windows.Forms.Label lblsalfam;
        private System.Windows.Forms.Label lblsalliq;
        private System.Windows.Forms.Label lbldescinss;
        private System.Windows.Forms.Label lbldescirpf;
        private System.Windows.Forms.Button btnverif;
        private System.Windows.Forms.MaskedTextBox msktxtsalb;
        private System.Windows.Forms.NumericUpDown numfilhos;
        private System.Windows.Forms.TextBox txtnome;
        private System.Windows.Forms.MaskedTextBox msktxtinss;
        private System.Windows.Forms.MaskedTextBox msktxtdescinss;
        private System.Windows.Forms.MaskedTextBox msktxtdescirpf;
        private System.Windows.Forms.MaskedTextBox msktxtirpf;
        private System.Windows.Forms.MaskedTextBox msktxtsalfam;
        private System.Windows.Forms.MaskedTextBox msktxtsalliq;
        private System.Windows.Forms.ErrorProvider errorSalBruto;
    }
}

