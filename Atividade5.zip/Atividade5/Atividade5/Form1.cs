﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade5
{
    public partial class Form1 : Form
    {
        double SalBruto, SalFamilia, SalLiquido, DescINSS, DescIRPF;
        int NumFilhos;

        

        char NomeFunc;

         public Form1()
        {
            InitializeComponent();
        }
        private void msktxtsalb_Validated(object sender, EventArgs e)
        {
            {
                errorSalBruto.SetError(msktxtsalb, "");

                if (!Double.TryParse(msktxtsalb.Text, out SalBruto))
                {
                    errorSalBruto.SetError(msktxtsalb, "Valor salário inválido!");
                }

            }
        }
        private void txtnome_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar))
            {
                SendKeys.Send("{BACKSPACE}");
            }
        }
        private void btnverif_Click(object sender, EventArgs e)
        {
            if (!Double.TryParse(msktxtsalb.Text, out SalBruto))
            {
                MessageBox.Show("Todos os campos devem ser preenchidos corretamente!");

                msktxtsalb.Focus();
            }
            else
            {
                Double.TryParse(msktxtsalb.Text, out SalBruto);
                int.TryParse(numfilhos.Text, out NumFilhos);

                if (SalBruto <= 800.47)
                {
                    msktxtinss.Text = "7,65%";
                    DescINSS = 0.0765 * SalBruto;
                }
                else if (SalBruto <= 1050)
                {
                    msktxtinss.Text = "8,65%";
                    DescINSS = 0.0865 * SalBruto;
                }
                else if (SalBruto <= 1400.17)
                {
                    msktxtinss.Text = "9,00%";
                    DescINSS = 0.09 * SalBruto;
                }
                else if (SalBruto <= 2801.56)
                {
                    msktxtinss.Text = "11,00%";
                    DescINSS = 0.11 * SalBruto;
                }
                else
                {
                    msktxtinss.Text = "27,50%";
                    DescINSS = 0.275 * SalBruto;
                }

                if (SalBruto <= 1257.12)
                {
                    msktxtirpf.Text = "Isento";
                    DescIRPF = 0;
                }
                else if (SalBruto <= 2512.08)
                {
                    msktxtirpf.Text = "15,00%";
                    DescIRPF = 0.15 * SalBruto;
                }
                else
                {
                    msktxtirpf.Text = "27,50%";
                    DescIRPF = 0.275 * SalBruto;
                }

                if (SalBruto <= 435.32)
                {
                    SalFamilia = NumFilhos * 22.33;
                    msktxtsalfam.Text = SalFamilia.ToString();
                }
                else if (SalBruto <= 654.61)
                {
                    SalFamilia = NumFilhos * 15.74;
                    msktxtsalfam.Text = SalFamilia.ToString();
                }
                else
                {
                    msktxtsalfam.Text = "R$ 0,00";
                    SalFamilia = 0;
                }

                msktxtdescinss.Text = DescINSS.ToString();
                msktxtdescirpf.Text = DescIRPF.ToString();

                SalLiquido = SalBruto + SalFamilia - DescINSS - DescIRPF;
                msktxtsalliq.Text = SalLiquido.ToString();
            }
        }
    }
}

      

       
       // private void label9_Click(object sender, EventArgs e)
        


        //private void msktxtsalb_Validated(object sender, EventArgs e)
       

       // private void msktxtsalb_Validated_1(object sender, EventArgs e)
       

       // private void maskedTextBox2_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
       

     //   private void textBox1_TextChanged(object sender, EventArgs e)
       

       // private void numericUpDown1_ValueChanged(object sender, EventArgs e)
      

       // private void button1_Click(object sender, EventArgs e)
       