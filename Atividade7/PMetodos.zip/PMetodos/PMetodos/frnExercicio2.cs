﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMetodos
{
    public partial class frnExercicio2 : Form
    {
        public frnExercicio2()
        {
            InitializeComponent();
        }

        private void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void TextBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void Button1_Click(object sender, EventArgs e)
        {
            if (String.Compare(txtpalavra1.Text, txtpalavra2.Text,true)==0)
            {
                MessageBox.Show("São iguais");

            }
            else
            {
                MessageBox.Show("São diferentes");
            }
        }

        private void Btninserir1_Click(object sender, EventArgs e)
        {
            int metade = txtpalavra2.Text.Length / 2;
            txtpalavra2.Text = txtpalavra2.Text.Substring(0, metade) +
            txtpalavra1.Text +
            txtpalavra2.Text.Substring(metade,
            txtpalavra2.Text.Length - metade);
        }

        private void Btninserir2_Click(object sender, EventArgs e)
        {
            int metade = txtpalavra1.Text.Length / 2;

            txtpalavra2.Text = txtpalavra1.Text.Insert(metade, "**");
        }
    }
}
