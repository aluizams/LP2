﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMetodos
{
    public partial class frnExercicio3 : Form
    {
        public frnExercicio3()
        {
            InitializeComponent();
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            txtpalavra1.Text = txtpalavra1.Text.ToUpper();
            txtpalavra2.Text = txtpalavra2.Text.ToUpper();
            txtpalavra2.Text = txtpalavra2.Text.Replace(txtpalavra1.Text, "");
        }

        private void Btnremover1_Click(object sender, EventArgs e)
        {
            int posicao = txtpalavra2.Text.IndexOf(txtpalavra1.Text,
                StringComparison.OrdinalIgnoreCase);

            while (posicao>=0)
            {
                txtpalavra2.Text = txtpalavra2.Text.Substring(0, posicao) +
                    txtpalavra2.Text.Substring(posicao + txtpalavra1.Text.Length,
                    txtpalavra2.Text.Length - posicao - txtpalavra1.Text.Length);

                posicao = txtpalavra2.Text.IndexOf(txtpalavra1.Text,
                StringComparison.OrdinalIgnoreCase);
            }
        }

        private void Btninverter_Click(object sender, EventArgs e)
        {
            //transforma string em array de char
            char[] vetorC = txtpalavra1.Text.ToCharArray();
            // inverter o array (vetor)
            Array.Reverse(vetorC);
            // voltar vetor para string
            foreach (char C in vetorC)
                txtpalavra2.Text += C;
        }
    }
}
