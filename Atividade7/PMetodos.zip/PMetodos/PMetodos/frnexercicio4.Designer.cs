﻿namespace PMetodos
{
    partial class frnexercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btntotnum = new System.Windows.Forms.Button();
            this.btncarcbranc = new System.Windows.Forms.Button();
            this.btntotletras = new System.Windows.Forms.Button();
            this.lbltxt = new System.Windows.Forms.Label();
            this.rchtxtfrase = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // btntotnum
            // 
            this.btntotnum.Location = new System.Drawing.Point(141, 313);
            this.btntotnum.Name = "btntotnum";
            this.btntotnum.Size = new System.Drawing.Size(110, 58);
            this.btntotnum.TabIndex = 0;
            this.btntotnum.Text = "Total Números";
            this.btntotnum.UseVisualStyleBackColor = true;
            this.btntotnum.Click += new System.EventHandler(this.Btntotnum_Click);
            // 
            // btncarcbranc
            // 
            this.btncarcbranc.Location = new System.Drawing.Point(359, 313);
            this.btncarcbranc.Name = "btncarcbranc";
            this.btncarcbranc.Size = new System.Drawing.Size(133, 58);
            this.btncarcbranc.TabIndex = 1;
            this.btncarcbranc.Text = "Posição 1º caracter branco";
            this.btncarcbranc.UseVisualStyleBackColor = true;
            this.btncarcbranc.Click += new System.EventHandler(this.Btncarcbranc_Click);
            // 
            // btntotletras
            // 
            this.btntotletras.Location = new System.Drawing.Point(559, 313);
            this.btntotletras.Name = "btntotletras";
            this.btntotletras.Size = new System.Drawing.Size(104, 58);
            this.btntotletras.TabIndex = 2;
            this.btntotletras.Text = "total letras";
            this.btntotletras.UseVisualStyleBackColor = true;
            this.btntotletras.Click += new System.EventHandler(this.Btntotletras_Click);
            // 
            // lbltxt
            // 
            this.lbltxt.AutoSize = true;
            this.lbltxt.Location = new System.Drawing.Point(128, 109);
            this.lbltxt.Name = "lbltxt";
            this.lbltxt.Size = new System.Drawing.Size(44, 20);
            this.lbltxt.TabIndex = 3;
            this.lbltxt.Text = "texto";
            this.lbltxt.Click += new System.EventHandler(this.Label1_Click);
            // 
            // rchtxtfrase
            // 
            this.rchtxtfrase.Location = new System.Drawing.Point(222, 106);
            this.rchtxtfrase.Name = "rchtxtfrase";
            this.rchtxtfrase.Size = new System.Drawing.Size(402, 158);
            this.rchtxtfrase.TabIndex = 4;
            this.rchtxtfrase.Text = "";
            this.rchtxtfrase.TextChanged += new System.EventHandler(this.RichTextBox1_TextChanged);
            // 
            // frnexercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.rchtxtfrase);
            this.Controls.Add(this.lbltxt);
            this.Controls.Add(this.btntotletras);
            this.Controls.Add(this.btncarcbranc);
            this.Controls.Add(this.btntotnum);
            this.Name = "frnexercicio4";
            this.Text = "frnexercicio4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btntotnum;
        private System.Windows.Forms.Button btncarcbranc;
        private System.Windows.Forms.Button btntotletras;
        private System.Windows.Forms.Label lbltxt;
        private System.Windows.Forms.RichTextBox rchtxtfrase;
    }
}