﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMetodos
{
    public partial class frnexercicio4 : Form
    {
        public frnexercicio4()
        {
            InitializeComponent();
        }

        private void Label1_Click(object sender, EventArgs e)
        {

        }

        private void RichTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Btntotnum_Click(object sender, EventArgs e)
        {
            int contador = 0;
            
            for (var i=0; i<rchtxtfrase.Text.Length; i++)
            {
                if (char.IsNumber(rchtxtfrase.Text[i]))
                    contador++; 
                        //contador =+1;
            }
            MessageBox.Show( $"a frase tem {contador} núemros");
            //MessageBox.Show("a frase tem "+contador+" numeros");
        }

        private void Btncarcbranc_Click(object sender, EventArgs e)
        {
            int contador = 0;
            int posicao = 0;

            while (contador<rchtxtfrase.Text.Length)
            {
                if (Char.IsWhiteSpace(rchtxtfrase.Text[contador]))
                {
                    posicao = contador + 1;
                    break;
                }
                contador += 1;
            }
            MessageBox.Show("O primeiro carcter em branco está na primeira posição " + posicao);
        }

        private void Btntotletras_Click(object sender, EventArgs e)
        {
            int contador = 0;

            foreach (var c in rchtxtfrase.Text)
            {
                if (char.IsLetter(c))

                    contador++;
            }

            MessageBox.Show($"a frase tem {contador} letras");

        }
    }
}
