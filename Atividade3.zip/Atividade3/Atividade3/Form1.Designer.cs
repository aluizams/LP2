﻿namespace Atividade3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btncalc = new System.Windows.Forms.Button();
            this.btnlimpar = new System.Windows.Forms.Button();
            this.btnsair = new System.Windows.Forms.Button();
            this.lblpeso = new System.Windows.Forms.Label();
            this.lblalt = new System.Windows.Forms.Label();
            this.lblimc = new System.Windows.Forms.Label();
            this.msktxtpeso = new System.Windows.Forms.MaskedTextBox();
            this.msktxtalt = new System.Windows.Forms.MaskedTextBox();
            this.msktxtimc = new System.Windows.Forms.MaskedTextBox();
            this.SuspendLayout();
            // 
            // btncalc
            // 
            this.btncalc.Location = new System.Drawing.Point(510, 104);
            this.btncalc.Name = "btncalc";
            this.btncalc.Size = new System.Drawing.Size(75, 23);
            this.btncalc.TabIndex = 0;
            this.btncalc.Text = "Calcular";
            this.btncalc.UseVisualStyleBackColor = true;
            this.btncalc.Click += new System.EventHandler(this.btncalc_Click);
            // 
            // btnlimpar
            // 
            this.btnlimpar.Location = new System.Drawing.Point(510, 185);
            this.btnlimpar.Name = "btnlimpar";
            this.btnlimpar.Size = new System.Drawing.Size(75, 23);
            this.btnlimpar.TabIndex = 1;
            this.btnlimpar.Text = "Limpar";
            this.btnlimpar.UseVisualStyleBackColor = true;
            this.btnlimpar.Click += new System.EventHandler(this.btnlimpar_Click);
            // 
            // btnsair
            // 
            this.btnsair.Location = new System.Drawing.Point(510, 265);
            this.btnsair.Name = "btnsair";
            this.btnsair.Size = new System.Drawing.Size(75, 23);
            this.btnsair.TabIndex = 2;
            this.btnsair.Text = "Sair";
            this.btnsair.UseVisualStyleBackColor = true;
            this.btnsair.Click += new System.EventHandler(this.btnsair_Click);
            // 
            // lblpeso
            // 
            this.lblpeso.AutoSize = true;
            this.lblpeso.Location = new System.Drawing.Point(154, 109);
            this.lblpeso.Name = "lblpeso";
            this.lblpeso.Size = new System.Drawing.Size(58, 13);
            this.lblpeso.TabIndex = 3;
            this.lblpeso.Text = "Peso Atual";
            this.lblpeso.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblalt
            // 
            this.lblalt.AutoSize = true;
            this.lblalt.Location = new System.Drawing.Point(154, 190);
            this.lblalt.Name = "lblalt";
            this.lblalt.Size = new System.Drawing.Size(34, 13);
            this.lblalt.TabIndex = 4;
            this.lblalt.Text = "Altura";
            // 
            // lblimc
            // 
            this.lblimc.AutoSize = true;
            this.lblimc.Location = new System.Drawing.Point(154, 270);
            this.lblimc.Name = "lblimc";
            this.lblimc.Size = new System.Drawing.Size(26, 13);
            this.lblimc.TabIndex = 5;
            this.lblimc.Text = "IMC";
            // 
            // msktxtpeso
            // 
            this.msktxtpeso.Location = new System.Drawing.Point(250, 107);
            this.msktxtpeso.Mask = "999,99";
            this.msktxtpeso.Name = "msktxtpeso";
            this.msktxtpeso.Size = new System.Drawing.Size(159, 20);
            this.msktxtpeso.TabIndex = 6;
            this.msktxtpeso.Validated += new System.EventHandler(this.msktxtpeso_Validated);
            // 
            // msktxtalt
            // 
            this.msktxtalt.Location = new System.Drawing.Point(250, 187);
            this.msktxtalt.Mask = "0,00";
            this.msktxtalt.Name = "msktxtalt";
            this.msktxtalt.Size = new System.Drawing.Size(159, 20);
            this.msktxtalt.TabIndex = 9;
            this.msktxtalt.Validated += new System.EventHandler(this.msktxtalt_Validated);
            // 
            // msktxtimc
            // 
            this.msktxtimc.Enabled = false;
            this.msktxtimc.Location = new System.Drawing.Point(250, 267);
            this.msktxtimc.Name = "msktxtimc";
            this.msktxtimc.Size = new System.Drawing.Size(159, 20);
            this.msktxtimc.TabIndex = 10;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.msktxtimc);
            this.Controls.Add(this.msktxtalt);
            this.Controls.Add(this.msktxtpeso);
            this.Controls.Add(this.lblimc);
            this.Controls.Add(this.lblalt);
            this.Controls.Add(this.lblpeso);
            this.Controls.Add(this.btnsair);
            this.Controls.Add(this.btnlimpar);
            this.Controls.Add(this.btncalc);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btncalc;
        private System.Windows.Forms.Button btnlimpar;
        private System.Windows.Forms.Button btnsair;
        private System.Windows.Forms.Label lblpeso;
        private System.Windows.Forms.Label lblalt;
        private System.Windows.Forms.Label lblimc;
        private System.Windows.Forms.MaskedTextBox msktxtpeso;
        private System.Windows.Forms.MaskedTextBox msktxtalt;
        private System.Windows.Forms.MaskedTextBox msktxtimc;
    }
}

