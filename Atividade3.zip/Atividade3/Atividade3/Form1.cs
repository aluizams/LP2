﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade3
{
    public partial class Form1 : Form
    {
        double peso, altura, imc;

        public Form1()
        {
            InitializeComponent();
        }

        private void btncalc_Click(object sender, EventArgs e)
        {
            if ((altura <= 0) || (peso <= 0))
                MessageBox.Show("Valores devem ser maiores que zero!");
            else
            {
                imc = peso / Math.Pow(altura, 2);
                imc = Math.Round(imc, 1); //arrendodei

                msktxtimc.Text = imc.ToString("N1");

                if (imc < 18.5)
                    MessageBox.Show("Magreza");
                else if (imc <= 24.9)
                    MessageBox.Show("Normal");
                else if (imc <= 29.9)
                    MessageBox.Show("Sobrepeso");
                else if (imc <= 39.9)
                    MessageBox.Show("Obesidade");
                else
                    MessageBox.Show("Obesidade grave");

            }
        }

        private void msktxtalt_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(msktxtalt.Text, out altura) || altura <= 0)
            {
                MessageBox.Show("Valor inválido");
                msktxtalt.Focus();
            }
        }

        private void btnlimpar_Click(object sender, EventArgs e)
        {
            msktxtpeso.Text = "";
            msktxtalt.Text = "";
            // volta para o numero 1 e limpa variaveis 
            msktxtpeso.Focus();
            imc = 0;
            peso = 0;
            altura = 0;
        }

        private void btnsair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Você deseja realmente sair?",
              "Saída", MessageBoxButtons.YesNo,
              MessageBoxIcon.Question) ==
              DialogResult.Yes)
            {
                Close();
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void msktxtpeso_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(msktxtpeso.Text, out peso) || peso <= 0)
            {
                MessageBox.Show("valor inválido!");
                msktxtpeso.Focus();
            }
        }
    }
}
